<?php

namespace CFPP\Exceptions;

/**
 * Class ShippingCalculatorException
 * @package CFPP\Exceptions
 */
class ShippingCalculatorException extends \Exception
{

}