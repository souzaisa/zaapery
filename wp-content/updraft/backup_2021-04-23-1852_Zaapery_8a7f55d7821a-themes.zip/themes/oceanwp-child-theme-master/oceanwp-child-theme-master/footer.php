<footer>
    <div class="footer-zaapery">
        <div class="logo-footer">
            <img src="<?php echo get_stylesheet_directory_uri();?>/assets/img/logobranco.png" alt="Logo zaapery">
        </div>
        <div class="menu-footer">
            <!-- Shortcode menu-->
            <?php echo do_shortcode('[menu name="Menu Principal"]'); ?>
        </div>
        <div class="icons-footer">
            <i class="fas fa-map-marker-alt">
                <a href=""><p>2972 Westheimer Rd. Santa Ana, Illinois 85486</p></a>
            </i>
            <i class="fas fa-phone-alt">
                <a href=""><p>(35)99999-9999</p></a>
            </i>
            <i class="fas fa-envelope">
                <a href=""><p>contato@zaapery.com.br</p></a>
            </i>
            <i class="fab fa-instagram-square">
                <a href=""><p>/zaapery</p></a>
            </i>
            <a class="site-seguro" href="https://www.google.com/transparencyreport/safebrowsing/diagnostic/?hl=pt-BR#url=zaapery.com.br" target="_blank"><img src="<?php echo get_stylesheet_directory_uri();?>/assets/img/google-report.png" alt="Site Seguro"></a>
        </div>
      
    </div>
    <div class="footer-copyright">
        <div class="container center">
            <p> Desenvolvido por </p>
            <a href="http://byronsolutions.com" target="_blank" title="Site da byron.solutions">
                <img src="<?php echo get_stylesheet_directory_uri();?>/assets/img/logo.png" alt="Logo da byron.solutions" title="Logo da byron.solutions">
            </a>
        </div>
    </div>
</footer>

<?php wp_footer() ?>
</body>
</html>
