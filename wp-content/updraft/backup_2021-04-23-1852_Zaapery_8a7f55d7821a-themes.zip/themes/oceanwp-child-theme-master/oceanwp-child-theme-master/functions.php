<?php
/**
 * Child theme functions
 *
 * When using a child theme (see http://codex.wordpress.org/Theme_Development
 * and http://codex.wordpress.org/Child_Themes), you can override certain
 * functions (those wrapped in a function_exists() call) by defining them first
 * in your child theme's functions.php file. The child theme's functions.php
 * file is included before the parent theme's file, so the child theme
 * functions would be used.
 *
 * Text Domain: oceanwp
 * @link http://codex.wordpress.org/Plugin_API
 *
 */

/**
 * Load the parent style.css file
 *
 * @link http://codex.wordpress.org/Child_Themes
 */
/* enqueue script for parent theme stylesheeet */        
function childtheme_parent_styles() {
 
	// enqueue style
	wp_enqueue_style( 'parent', get_template_directory_uri().'/assets/css/style.min.css' );                       
   }
   add_action( 'wp_enqueue_scripts', 'childtheme_parent_styles');
function oceanwp_child_enqueue_parent_style() {
	// Dynamically get version number of the parent stylesheet (lets browsers re-cache your stylesheet when you update your theme)
	$theme   = wp_get_theme( 'OceanWP' );
	$version = $theme->get( 'Version' );
	// Load the stylesheet
	wp_enqueue_style( 'child-style', get_stylesheet_directory_uri() . '/style.css');
	wp_enqueue_style( 'child-materialize', get_stylesheet_directory_uri() . '/materialize/css/materialize.css', array( 'oceanwp-style' ), $version );

	wp_enqueue_script( 'jquery', 'https://code.jquery.com/jquery-3.3.1.min.js', array(), false, true );
	wp_enqueue_script( 'materialize_js', 'https://cdnjs.cloudflare.com/ajax/libs/materialize/1.0.0/js/materialize.min.js', array('jquery'), '1.0.0', true );
	wp_enqueue_script( 'script.js ',  get_stylesheet_directory_uri() .'/assets/js/script.js', false, '' );
	wp_enqueue_script('fontawesome', "https://kit.fontawesome.com/dfb8742735.js", array(), false, true);
}
add_action( 'wp_enqueue_scripts', 'oceanwp_child_enqueue_parent_style' );

//Shortcode menu, usado no footer
function print_menu_shortcode($atts, $content = null) {
	extract(shortcode_atts(array( 'name' => null, 'class' => null ), $atts));
	return wp_nav_menu( array( 'menu' => $name, 'menu_class' => 'myclass', 'echo' => false ) );
}
add_shortcode('menu', 'print_menu_shortcode');

//Barra superior para o usuário logado
add_filter( 'ocean_display_top_bar', 'topbar_conditional_display' );
 // Topbar conditional display
 function topbar_conditional_display( $return ) {
 
	if ( is_user_logged_in() ) {
		$return = true;
	 } else {
		$return = false; 
	}

	// Return
	return $return;
	
}