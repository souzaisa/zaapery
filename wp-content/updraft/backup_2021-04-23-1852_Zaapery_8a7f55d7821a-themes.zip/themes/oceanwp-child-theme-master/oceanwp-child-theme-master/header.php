<?php
/**
 * The Header for our theme.
 *
 * @package OceanWP WordPress theme
 */ ?>

<!DOCTYPE html>
<html class="<?php echo esc_attr( oceanwp_html_classes() ); ?>" <?php language_attributes(); ?>>
<head>
	<meta charset="<?php bloginfo( 'charset' ); ?>">
	<link rel="profile" href="https://gmpg.org/xfn/11">

	<?php wp_head(); ?>
</head>

<body <?php body_class(); ?> <?php oceanwp_schema_markup( 'html' ); ?>>

	<?php wp_body_open(); ?>

	<?php do_action( 'ocean_before_outer_wrap' ); ?>

	<div id="outer-wrap" class="site clr">

		<a class="skip-link screen-reader-text" href="#main"><?php esc_html_e( 'Skip to content', 'oceanwp' ); ?></a>

		<?php do_action( 'ocean_before_wrap' ); ?>
		
		<div id="wrap" class="clr">

			<?php do_action( 'ocean_top_bar' ); ?>

			<?php do_action( 'ocean_header' ); ?>
			<div class="navbarCategoria">
			 <?php echo do_shortcode( '[product_categories orderby="popularity" hide_empty = 0 columns = 8]' ); ?>
			 </div>
			<?php if(is_front_page()) :  ?>
			<div class="banner carousel carousel-slider">
				<div class="carousel-prev">
				<a class="prev waves-effect waves-light">
					<i class="fas fa-chevron-left"></i>
                </a>
				</div>
				<a class="carousel-item" href="#two!"><img src="<?php echo get_stylesheet_directory_uri();?>/assets/img/joyce-romero-tC-TOGGEODI-unsplash-1-e1595014308890.png"></a>
				<a class="carousel-item" href="#three!"><img src="<?php echo get_stylesheet_directory_uri();?>/assets/img/mel-poole-4byBtNuIyIg-unsplashedit-1.jpg"></a>
				<div class="carousel-next">
				<a class="next waves-effect waves-light">
					<i class="fas fa-chevron-right"></i>
                </a>
				</div>
				
  			</div>
			<?php endif; ?>


			<?php do_action( 'ocean_before_main' ); ?>

			<main id="main" class="site-main clr"<?php oceanwp_schema_markup( 'main' ); ?> role="main">

