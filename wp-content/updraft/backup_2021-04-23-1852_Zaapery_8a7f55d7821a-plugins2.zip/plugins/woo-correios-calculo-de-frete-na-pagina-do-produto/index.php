<?php // Code is poetry!
