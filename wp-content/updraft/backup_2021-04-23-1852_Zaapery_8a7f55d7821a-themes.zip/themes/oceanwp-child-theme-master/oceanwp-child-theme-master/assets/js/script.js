jQuery.noConflict();

jQuery(function ($) {
    $(document).ready(function(){
    $('.carousel.carousel-slider').carousel({
        fullWidth: true,
        indicators: true
    });

    $('.next').click(function(){
        $('.carousel').carousel('next');
    });
    $('.prev').click(function(){
        $('.carousel').carousel('prev'); 
    });

});
});